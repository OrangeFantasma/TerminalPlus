# TerminalPlus
Introduces several convenient/useful commands
## tp
the same as pushing the button, will fail if the teleporter is on cooldown or not purchased
## detailedscan
shows all the lootable items not yet collected